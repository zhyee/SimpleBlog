<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/6/28 0028
 * Time: 18:28
 */

/**
 * @SWG\TAG(
 *     name="文章接口",
 *     description="关于文章的所有接口"
 * )
 * @SWG\TAG(
 *     name="用户接口",
 *     description="关于用户的所有接口"
 * )
 */

namespace frontend\modules\api\controllers;

use yii\web\Controller;

class ApiController extends Controller {

}