<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/3/13
 * Time: 22:08
 */
use yii\helpers\Html;
echo Html::encode($message);