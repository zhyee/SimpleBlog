<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/6/28 0028
 * Time: 18:48
 */

namespace frontend\modules\api\models;

use yii\db\ActiveRecord;

class Article extends ActiveRecord {



}


