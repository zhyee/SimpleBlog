<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/6/27 0027
 * Time: 10:37
 */

namespace frontend\modules\article;

use yii\base\Module;

class ArticleModule extends Module {

}