<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/6/27 0027
 * Time: 10:45
 */

namespace frontend\modules\article\controllers;

use frontend\controllers\FrontendBaseController;

class ArticleBaseController extends FrontendBaseController {



}